<?php 

include "/var/www/html/book_company/Booktype/book.php" ;

class Author
{

	private $books_count,$publications,$book_details;

	function __construct($books_count,$publications)
	{
		$this->books_count  = $books_count;
		$this->publications = $publications;
		$this->book_details = new Book("Harry Potter","1000","2001","250");
		$this->book_details = $this->book_details->getBookDetails();
	}

	function getAuthorDetails(){
		return [$this->books_count,$this->publications,$this->book_details];
	}

	public function writeBook(){

	}
	public function referResources(){

	}
	public function createIndex(){

	}
}

$author1 = new Author("10","2");
$author_details = $author1->getAuthorDetails();

echo "<pre>";
print_r($author_details);
echo "</pre>";
 ?>