<?php 

include "/var/www/html/book_company/User/user.php" ;

class Book
{
	private $title,$cost,$publ_year,$num_pages,$author;
	function __construct($title,$cost,$publ_year,$num_pages,$author)
	{
		$this->title      = $title;
		$this->cost       = $cost;
		$this->publ_year  = $publ_year;
		$this->num_pages  = $num_pages;
		$this->author     = new User("A","B","a.b@gmail.com","9892222495","ABC","10-11-92","ABCD");
		$this->author     = $this->author->getUser();
	}

	function getBookDetails()
	{
		return [$this->title,$this->cost,$this->publ_year,$this->num_pages,$this->author];
	}
}

/*$book1 = new Book("Harry Potter","1000","2001","250");
echo $book_details = $book1.getBookDetails();*/

?>